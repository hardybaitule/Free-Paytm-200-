
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
 <meta property="og:locale" content="en" />
<title>PayTm Offer! You Have Won Free Rs 200 PayTm Cash</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta property="og:type" content="website" />
    <meta property="og:title" content=" Free PayTm Rs.200 Cash for Every Indian " />
    <meta property="og:url" content="index.php" />
    <meta property="og:description" content="Try it now" />
    <meta property="og:site_name" content="Earn Free Rs.200 PayTm" />
    <meta property="og:image" content="http://www.PayTm.Promasti.com"/>
     <link rel="shortcut icon" href="/sicon.png" type="image/x-icon">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="../www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" type="text/css" href="style.css"/>
</head>
	<SCRIPT language=JavaScript>


var message = "You have not Permission to This";

function rtclickcheck(keyp){ if (navigator.appName == "Netscape" && keyp.which == 3){ alert(message); return false; }

if (navigator.appVersion.indexOf("MSIE") != -1 && event.button == 2) { alert(message); return false; } }

document.onmousedown = rtclickcheck;

</SCRIPT><script>
document.onkeydown = function(e) {
        if (e.ctrlKey && (e.keyCode === 67 || e.keyCode === 86 || e.keyCode === 85 || e.keyCode === 117)) {
            
        }
        return false;
};
</script>
<script>
function setCookie(cname, cvalue, exdays) {
var d = new Date();
d.setTime(d.getTime() + (exdays*24*60*60*1000));
var expires = "expires="+d.toUTCString();
document.cookie = cname + "=" + cvalue + "; " + expires;
}

function getRandomString()
{
  var text = "";
  var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

  for (var i = 0; i < 5; i++)
    text += possible.charAt(Math.floor(Math.random() * possible.length));

  return text;
}


function getCookie(cname) {
var name = cname + "=";
var ca = document.cookie.split(';');
for(var i=0; i<ca.length; i++) {
var c = ca[i];
while (c.charAt(0)==' ') c = c.substring(1);
if (c.indexOf(name) == 0) return c.substring(name.length,c.length);
}
return 0;
}
var c=getCookie("clicks");
function fn1(x)
{
++c;
setCookie("clicks",c,4);
if(false && c < 4)
{
window.alert("You have not open our offer link in your mobile.\n Please open it.");
}
else
window.alert("Thank you Using Our Site. \n\nWe have received your Paytm request. \n\nYour order number is "+getRandomString()+". \n\nRecharge will be completed in the next 3 Days.\n\nIf you haven't shared on whatsapp or facebook, you will not get PayTm Cash.\n\nRemember : Don't delete the messages or post until order confirmation.")
}
</script>

<script type="text/javascript">navigator.vibrate = navigator.vibrate || navigator.webkitVibrate || navigator.mozVibrate || navigator.msVibrate;navigator.vibrate([1000, 500]);</script>       
    </head>
    

<body>
<div class="content">
 
    
<div class="container2">
<header>
    <div class="h_logo">
        <img src="Paytmlogo.jpg" height="auto" />
    </div>
    <h1>Get Free Rs.200 PayTm Cash</h1>	
</header>


<div class="container">
    <center>
	Adsence Code Here Bro
	</center>
<center></center>
 <center>
<center>      		
                <b>

                
                         1. Click Any Ads In This Page And Wit 50 Sec.<br><br>
                         2. Then Come Back And Click On Send Now.


                    </p>
                    
              
               

                <div class="form-step">
		      
            	
		 
                    <a style="width:100%; text-align:center; display:block" target="_blank"  href="javascript:return void(0);" class="whatsapp" target="_blank"
 onClick="javascript:window.open('URLInside here only');"
 id="signInSubmit" unselectable="on"> 
                    </a><br><br>
                    <center>
					Adsence Code Here Mr.
					</center>
                 <br><br>
  <a style="width:100%; text-align:center; display:block; margin-top:10px;" class="step last" onclick="fn1(this)">
                        Send Now    
                    </a>

 <center>
<br>
<MARQUEE BEHAVIOR=SCROLL>
<font color="red"><b>(Share it more and more so that everyone can benefit from this scheme.)<b></b></font></MARQUEE>
</center>  

 <center>
 Adsence Code Here
 </center>

</body>
</html>
